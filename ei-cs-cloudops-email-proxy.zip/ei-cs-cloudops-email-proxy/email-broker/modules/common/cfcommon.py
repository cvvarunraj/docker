# Cloud Function common settings and functions

from google.cloud import logging
from google.cloud.logging.resource import Resource

from modules.utilities.printutilities import print_message, debug_message


CLOUD_FUNCTION_NAME = None # Cloud Function Name. Used for stackdriver logging
CLOUD_FUNCTION_PROJECT = None # Cloud Function Project. Used for stackdriver logging
CLOUD_FUNCTION_REGION = None # Cloud Function Region. Used for stackdriver logging
LOG_TO_STACKDRIVER = True


class CloudFunctionLog:
    def __init__(self):
        self.logClient = logging.Client()
        self.logName = 'cloudfunctions.googleapis.com%2Fcloud-functions'  # We always want to log to the cloud function
        self.resource = Resource(type="cloud_function", labels={"function_name": CLOUD_FUNCTION_NAME, "region": CLOUD_FUNCTION_REGION})
        self.logger   = self.logClient.logger(self.logName.format(CLOUD_FUNCTION_PROJECT))

    def log(self, payload, severity="INFO"):
        self.logger.log_struct(payload, resource=self.resource, severity=severity)