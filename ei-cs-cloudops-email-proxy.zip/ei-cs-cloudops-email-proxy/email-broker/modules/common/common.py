# Set common configurations that's shared among multiple modules

VERBOSITY = 1 # 1 = Normal, 2 = Debug, 3 = ??
TOOL_NAME = "UNKNOWN"