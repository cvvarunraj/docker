from enum import Enum

# #############################################################
# Cloud Policy Enforcement
# #############################################################
# Below are classes which assist in policy enforcement

# These actions can be taken when an instance is out of policy. Ordering of the number is important as the higher the number, the more severe the action is.
# For example, if an instance violates two policies. One with a STOP action and one with a DELETE action, the instance will be deleted since DELETE has a higer value than STOP
class PolicyAction(Enum):
    DISABLED = 0
    TRACK = 1
    STOP = 2
    DELETE = 3

# Result of a Policy check
class PolicyResult(Enum):
    UNKNOWN = 0
    COMPLIANT = 1
    NOTCOMPLIANT = 2

# Result of Policy Enforcement
class PerformedAction(Enum):
    NONE = 0
    STOPPED = 1
    DELETED = 2

class Policy:
    def __init__(self, name, violationAction, description=None):
        if not isinstance(violationAction, PolicyAction):
            raise TypeError("Provided violationAction is not of type PolicyAction (received %s)" % (type(violationAction)) )

        self.name = name
        self.description = description # A more friendly description of the policy
        self.violationAction = violationAction
        self.result = PolicyResult.UNKNOWN
    
    def SetResult(self, result):
        if not isinstance(result, PolicyResult):
            raise TypeError("Provided result is not of type PolicyResult (received %s)" % (type(result)) )
        self.result = result