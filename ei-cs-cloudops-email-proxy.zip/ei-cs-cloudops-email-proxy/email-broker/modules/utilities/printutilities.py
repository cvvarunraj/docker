# Common utilities that are needed across all functions
import modules.common.common as common

def print_message(str, end='\n', flush=True):
    """
    Abstracts the print() function
    """
    print(str, end=end, flush=flush)


def debug_message(str, end='\n', flush=True):
    """
    Prints a message depending on VERBOSITY setting
    """

    if common.VERBOSITY >= 2:
        print_message(str, end=end, flush=flush)