# Common dictionary functions

def get_value_from_dict(key, dictionary, default=None, throw=False):
    """
    Returns the value for the key in the provided dictionary. if no matching key found, returns None.
    If throw is true, an exception is thrown if the key doesn't exist
    """
    if value_in_dict(key, dictionary):
        return dictionary[key]
    if throw:
        raise KeyError("'%s' not in dictionary" % (key)) 
    return default

def value_in_dict(key, dictionary):
    """
    Returns bool depending on whether key is in the dictionary
    """
    if key in dictionary:
        return True
    return False