# Date Utilities
import datetime
import pytz
import iso8601

def convert_tz_to_utc_offset(timezone):
    """
    Takes a timezone (ex: America/Vancouver) and returns the UTC offset in format of (-0700)
    For a list of timezones, see here: https://en.wikipedia.org/wiki/List_of_tz_database_time_zones
    
    Parameters:
      String in proper timezone format (ex: America/Vancouver)
    """
    return datetime.datetime.now(pytz.timezone(timezone)).strftime('%z')

def parse_rfc3389_to_datetime(date_string):
    """
    Takes a dateString in RFC3389 format (Example: 2019-06-30T03:17:24.974-07:00)
    
    Returns a datetime object in UTC time
    """
    return iso8601.parse_date(date_string).astimezone(pytz.utc)

def get_current_date_time():
    """
    Returns a DateTime object with the current UTC time
    """
    return datetime.datetime.utcnow().replace(tzinfo=pytz.UTC)
