# For Email
import smtplib
from os.path import basename
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate

from ..utilities.printutilities import print_message, debug_message

# Functions
def send_mail(send_from, send_to, subject, text, html_text, files=None, server="127.0.0.1", cc=[], bcc=[]):
    assert isinstance(send_to, list)

    msg = MIMEMultipart('alternative')
    msg['From'] = send_from
    msg['To'] = COMMASPACE.join(send_to)
    msg['CC'] = COMMASPACE.join(cc)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    debug_message("Sending email to: %s (CC: %s / BCC: %s)" % (msg['To'], msg['CC'], COMMASPACE.join(bcc)))
    if text is None and html_text is None:
        raise ValueError("No message body provided")
    if text is not None:
        msg.attach(MIMEText(text, 'plain'))
    if html_text is not None:
        msg.attach(MIMEText(html_text, 'html'))


    smtp = smtplib.SMTP(server)
    send_to = send_to + cc + bcc
    smtp.sendmail(send_from, send_to, msg.as_string())
    smtp.close()
    debug_message("Sent")