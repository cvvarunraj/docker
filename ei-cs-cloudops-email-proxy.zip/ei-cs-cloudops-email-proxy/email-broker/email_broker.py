# Summary: Takes a well-structured json payload and sends an email based on the content
# Background: Cloud Functions currently can't access our shared VPC IP space. As such, we cannot use the internal SMTP relay.
#   As a workaround, this tool can be spun up on an instance. It will listen on a Pub/Sub subscription and send off emails to the configured relay

# Example payload:
#
#   {
#       "To": ["kirby.lagroix@changehealthcare.com"],
#       "CC": ["kirby.lagroix@changehealthcare.com"],
#       "BCC": ["kirby.lagroix@changehealthcare.com"],
#       "From": "ei-cs-cloudops-resource-administration@noreply.com",
#       "Subject": "Testing",
#       "BodyHtml": "",
#       "BodyTest": ""
#   }

# To, CC, BCC all take a list of emails. BCC and CC are optional
# At least one of BodyHtml/BodyTest must be provided. Both can be provided as well for a multipart email

import os
import json
import datetime
import traceback
from google.cloud import pubsub

import modules.common.common as common
from modules.utilities.printutilities import print_message, debug_message
import modules.utilities.emailutilities as emailutilities
import modules.utilities.dictutilities as dictutilities

common.VERBOSITY = 2  # Set Debug
common.TOOL_NAME = "email_broker"

CONFIG_FILE = "/usr/local/bin/email_broker/email_broker_config.json"
SUBSCRIPTION = None
MAIL_RELAY = None


def callback(message):
    print_message("Received message [%s]" % (datetime.datetime.now()))
    clean_message = json.loads(message.data.decode('utf-8'))
    debug_message("------------------------------------")
    debug_message(json.dumps(clean_message, indent=4, sort_keys=True))
    debug_message("------------------------------------")

    try:
        to = dictutilities.get_value_from_dict("To", clean_message, throw=True)                    # Required
        cc = dictutilities.get_value_from_dict("CC", clean_message, default=[], throw=False)       # Optional
        bcc = dictutilities.get_value_from_dict("BCC", clean_message, default=[], throw=False)     # Optional
        fromaddr = dictutilities.get_value_from_dict("From", clean_message, throw=True)            # Required
        subject = dictutilities.get_value_from_dict("Subject", clean_message, throw=True)          # Required
        
        html = dictutilities.get_value_from_dict("BodyHtml", clean_message, default=None, throw=False)
        text = dictutilities.get_value_from_dict("BodyText", clean_message, default=None, throw=False)

        if html is None and text is None:
            raise KeyError("Neither BodyHtml nor BodyText provided")
    except KeyError as err:
        print_message("Unable to process from message. Required field missing (Exception: %s). Nacking" % (err))
        message.nack()
        return
    
    try:
        print_message("Sending email to %s from %s" % (to, fromaddr), end="")
        emailutilities.send_mail(fromaddr, to, subject, text, html, files=None, server=MAIL_RELAY, cc=cc, bcc=bcc)
        print_message("DONE")
    except:
        exceptionText = traceback.format_exc()
        print_message("Caught unknown exception while sending email. Traceback: %s" % (exceptionText))
        print_message("Nacking")
        
        message.nack()
        return
    
    message.ack()
    return


# We have a config, lets try load it
print("Loading Configuration (%s)..." % (CONFIG_FILE), end='')
config = None
with open(CONFIG_FILE) as json_data_file:
    config = json.load(json_data_file)
print("DONE")

SUBSCRIPTION = config["Subscription"]
MAIL_RELAY = config["MailRelay"]


start_time = datetime.datetime.now()
print_message("Started %s [%s]" % (common.TOOL_NAME, start_time))

subscriber = pubsub.SubscriberClient()

print_message("Subscribing...", end="")
subscription = subscriber.subscribe(SUBSCRIPTION, callback)
print_message("OK\n")

try:
    subscription.result()
except KeyboardInterrupt:
    subscription.cancel()
