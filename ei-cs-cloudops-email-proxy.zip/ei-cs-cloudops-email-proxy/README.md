Some resources (like Cloud Functions) can't access SMTP servers on our VPC network.
This is VM instance which proxies emails via Pub/Sub.